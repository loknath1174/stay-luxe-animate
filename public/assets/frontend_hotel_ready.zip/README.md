# Frontend (sample)
This folder contains a minimal React scaffold separated from the backend so both can be developed independently.

Files included:
- package.json (minimal dependencies)
- public/index.html (simple root HTML)
- src/App.js (sample app)
- README explaining how to run frontend separately.

This scaffold is intentionally minimal so it doesn't interfere with the backend Spring Boot app.
