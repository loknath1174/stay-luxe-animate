
import React from 'react';
export default function ProfilePage(){ return (
  <div className="card"><h2>Your Profile</h2><p>Name: Demo User</p></div>
) }
