
import React, {useState} from 'react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';

export default function RoomSearch(){ 
  const [from,setFrom]=useState(new Date());
  const [to,setTo]=useState(new Date());
  return (
    <div className="card">
      <h4>Search Rooms</h4>
      <div className="form-inline">
        <label>From</label>
        <DatePicker selected={from} onChange={d=>setFrom(d)} />
        <label>To</label>
        <DatePicker selected={to} onChange={d=>setTo(d)} />
        <button className="btn">Search</button>
      </div>
    </div>
  )
}
