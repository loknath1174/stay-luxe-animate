
import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import ApiService from '../../service/ApiService';

const Navbar = () => {
  const isAuthenticated = ApiService.isAuthenticated ? ApiService.isAuthenticated() : false;
  const isAdmin = ApiService.isAdmin ? ApiService.isAdmin() : false;
  const navigate = useNavigate();

  const handleLogout = () => {
    if (window.confirm('Logout?')) {
      ApiService.logout && ApiService.logout();
      navigate('/home');
    }
  };

  return (
    <header className="header">
      <div style={{display:'flex',alignItems:'center',gap:12}}>
        <NavLink to="/home" style={{color:'white',fontWeight:700,textDecoration:'none'}}>Phegon Hotel</NavLink>
      </div>
      <nav className="nav">
        <NavLink to="/home" className={({isActive})=>isActive?'active':''}>Home</NavLink>
        <NavLink to="/rooms" className={({isActive})=>isActive?'active':''}>Rooms</NavLink>
        <NavLink to="/find-booking" className={({isActive})=>isActive?'active':''}>Find Booking</NavLink>
        {isAuthenticated ? <NavLink to="/profile" className={({isActive})=>isActive?'active':''}>Profile</NavLink> : <NavLink to="/login" className={({isActive})=>isActive?'active':''}>Login</NavLink>}
        {isAdmin && <NavLink to="/admin" className={({isActive})=>isActive?'active':''}>Admin</NavLink>}
        {isAuthenticated && <button onClick={handleLogout} className="btn" style={{padding:'6px 8px'}}>Logout</button>}
      </nav>
    </header>
);
};

export default Navbar;
