
import React from 'react';
export default function RoomResult({roomSearchResults}){
  return (
    <div className="rooms-grid" style={{marginTop:12}}>
      {roomSearchResults && roomSearchResults.map(room=> (
        <div key={room.id} className="card room-item">
          <img src={room.roomPhotoUrl} alt={room.roomType} />
          <div className="meta">
            <h4>{room.roomType}</h4>
            <p style={{color:'#666'}}>{room.roomDescription}</p>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
              <strong>₹{room.roomPrice}</strong>
              <a href="#" className="btn">Book</a>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}
