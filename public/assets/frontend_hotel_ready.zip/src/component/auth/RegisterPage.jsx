
import React from 'react';
export default function Register(){ return (
  <div className="card"><h3>Register</h3><p>Registration form placeholder.</p></div>
) }
