
import React, {useState} from 'react';
export default function LoginPage(){
  const [email,setEmail]=useState('');
  const [pw,setPw]=useState('');
  const submit = (e)=>{ e.preventDefault(); alert('Fake login - storing token'); localStorage.setItem('token','demo'); localStorage.setItem('role','USER'); window.location.href='/home'; }
  return (
    <div className="card" style={{maxWidth:420}}>
      <h3>Login</h3>
      <form onSubmit={submit} className="form-inline">
        <input required placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
        <input required placeholder="Password" type="password" value={pw} onChange={e=>setPw(e.target.value)} />
        <button className="btn" type="submit">Login</button>
      </form>
    </div>
  )
}
