
import React from 'react';
export default function FindBooking(){ return (
  <div className="card"><h3>Find Booking</h3><p>Enter your booking id or email to find your reservation.</p></div>
) }
