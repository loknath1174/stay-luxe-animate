
import React from 'react';
import RoomSearch from '../common/RoomSearch';
import RoomResult from '../common/RoomResult';

const sampleRooms = [
  {id:1, roomType:'Deluxe King', roomPhotoUrl:'https://picsum.photos/seed/room1/600/400', roomPrice:3500, roomDescription:'Spacious room with king bed.'},
  {id:2, roomType:'Standard Twin', roomPhotoUrl:'https://picsum.photos/seed/room2/600/400', roomPrice:2500, roomDescription:'Cozy twin beds with city view.'},
  {id:3, roomType:'Suite', roomPhotoUrl:'https://picsum.photos/seed/room3/600/400', roomPrice:5500, roomDescription:'Luxury suite with living area.'}
];

export default function RoomsPage(){
  return (
    <div>
      <RoomSearch />
      <RoomResult roomSearchResults={sampleRooms} />
    </div>
  )
}
