
import React from 'react';
export default function HomePage(){return (
  <div className="card">
    <h2>Welcome to Phegon Hotel</h2>
    <p>Comfortable stays, modern amenities, and best-in-class service.</p>
    <div style={{marginTop:12}}>
      <a href="/rooms" className="btn">Explore Rooms</a>
    </div>
  </div>
) }
