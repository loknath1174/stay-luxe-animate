import React from 'react';

const FindBooking = () => (<div><h2>Find Booking</h2><p>Search your bookings here.</p></div>); export default FindBooking;
