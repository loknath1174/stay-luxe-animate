
import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './component/common/Navbar';
import HomePage from './component/home/HomePage';
import RoomsPage from './component/booking_rooms/AllRoomsPage';
import FindBooking from './component/booking_rooms/FindBookingPage';
import ProfilePage from './component/profile/ProfilePage';
import LoginPage from './component/auth/LoginPage';
import RegisterPage from './component/auth/RegisterPage';
import AdminPage from './component/admin/AdminPage';
import NotFound from './component/common/NotFound';
import './styles.css';

function App() {
  return (
    <div className="app-container">
      <Navbar />
      <main className="main">
        <Routes>
          <Route path="/" element={<Navigate to="/home" replace />} />
          <Route path="/home" element={<HomePage />} />
          <Route path="/rooms" element={<RoomsPage />} />
          <Route path="/find-booking" element={<FindBooking />} />
          <Route path="/profile" element={<ProfilePage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/admin" element={<AdminPage />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <footer className="footer">© Phegon Hotel — demo frontend scaffold</footer>
    </div>
  );
}

export default App;
