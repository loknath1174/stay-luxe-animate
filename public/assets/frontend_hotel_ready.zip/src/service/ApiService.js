
import axios from 'axios';

const ApiService = {
  isAuthenticated: () => !!localStorage.getItem('token'),
  isAdmin: () => localStorage.getItem('role') === 'ADMIN',
  isUser: () => localStorage.getItem('role') === 'USER',
  logout: () => { localStorage.removeItem('token'); localStorage.removeItem('role'); },
  get: (url) => axios.get(url),
  post: (url, data) => axios.post(url, data)
};

export default ApiService;
